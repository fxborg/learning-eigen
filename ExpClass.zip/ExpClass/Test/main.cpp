
#include <Windows.h>
#include <tchar.h>
#include <iostream>
typedef int(__stdcall *Fn_ExpClass_Create)(int);
typedef int(__stdcall *Fn_ExpClass_Push)(int, int, double);
typedef double(__stdcall *Fn_ExpClass_SMA)(int);
typedef int(__stdcall *Fn_ExpClass_Destroy)(int);
int main()
{
	HMODULE hDll = ::LoadLibrary(_T("ExpClass.dll"));

	Fn_ExpClass_Create ExpClass_Create = (Fn_ExpClass_Create)GetProcAddress(hDll, "Exp_Create");
	Fn_ExpClass_Destroy ExpClass_Destroy = (Fn_ExpClass_Destroy)GetProcAddress(hDll, "Exp_Destroy");
	Fn_ExpClass_Push ExpClass_Push = (Fn_ExpClass_Push)GetProcAddress(hDll, "Exp_Push");
	Fn_ExpClass_SMA ExpClass_SMA = (Fn_ExpClass_SMA)GetProcAddress(hDll, "Exp_SMA");
	int ptr = ExpClass_Create(20);
	double sma;
	for (int i = 0; i<50; i++)
	{
		int n = ExpClass_Push(ptr, i, i * 100 + i);
		sma = ExpClass_SMA(ptr);
		std::cout << n << "->" << sma << std::endl;
	}
	int v = ExpClass_Destroy(ptr);

	//dll�ō쐬�����N���X�C���X�^���X���쐬����
	system("pause");
	return 0;
}

