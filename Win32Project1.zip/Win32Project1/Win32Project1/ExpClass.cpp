#include "ExpClass.h"
#include <iostream>

CExpClassBase* CreateCExpClassInstance()
{
	return new CExpClass;
}

CExpClass::CExpClass()
{
	std::cout << "NEW TEST!";
}
void CExpClass::Func()
{
	std::cout << "FUNC TEST!";

}
void CExpClass::Destroy()
{
	delete this;
}
