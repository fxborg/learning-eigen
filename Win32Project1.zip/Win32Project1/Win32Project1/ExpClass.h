

class CExpClassBase {
public:
	
	virtual void Func(void)=0;
	virtual void Destroy(void)=0;

};


class CExpClass : public CExpClassBase
{
public:
	CExpClass();
	void Func(void);
	void Destroy(void);
};



CExpClassBase* CreateCExpClassInstance(void);
