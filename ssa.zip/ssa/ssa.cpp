﻿//+------------------------------------------------------------------+
//|                                                          ssa.cpp |
//| SSA Trend                                 Copyright 2017, fxborg |
//| this is a c++ reimplementation of AutoSSA Matlab package         |
//| AutoSSA(http://www.pdmi.ras.ru/~theo/autossa/english/soft.htm)   |
//|                                   http://fxborg-labo.hateblo.jp/ |
//+------------------------------------------------------------------+

#include "ssa.h"
EXPORT CSSA * __stdcall Create(const size_t size, const size_t length, const  double omega0, const size_t max_et, const double c0step) {

	return new CSSA(size, length, omega0, max_et, c0step);
}

EXPORT void __stdcall Destroy(CSSA * instance)
{
	delete instance;
}

EXPORT int __stdcall Push(CSSA * instance, const int x, const double y, const time_t t0, const time_t t1)
{
	return instance->push(x, y, t0, t1);
}
EXPORT int __stdcall Calculate(CSSA* instance)
{
	return instance->calculate();
}
EXPORT bool __stdcall GetResults(CSSA * instance, const size_t idx, double &y)
{
	return instance->get_results(idx, y);
}

bool CSSA::get_results(const size_t idx, double &y)
{
	if (m_results.size() <= idx) return false;
	y = m_results[idx];
	return true;
}

CSSA::CSSA(const size_t size, const size_t length, const  double omega0, const size_t max_et, const double c0step) :
	m_size(minmax(size, 50, 2000)),
	m_L(minmax(length, 5, m_size)),
	m_omega0(minmax(omega0, 0.001, 0.5)),
	m_max_et(minmax(max_et, 2, int(0.5*m_L))),
	m_c0min(0.5),
	m_c0max(1.0),
	m_c0step(c0step),
	m_rdelta_threshold(0.05),
	m_c0eps(0),
	m_series(CSeries(m_size + 1))
{}


int CSSA::push(const int x, const double y, const time_t t0, const time_t t1)
{
	int result = 0;
	try
	{
		result = m_series.push(x, y, t0, t1);
	}
	catch (...)
	{
		result = -9999;
	}

	return result;
}

int CSSA::calculate()
{
	if (!m_series.is_adding())return 0;
	const std::deque<double> & series = m_series.get_stats_series();
	if (series.size() != m_size + 1)return 0;

	m_results.erase(m_results.begin(), m_results.end());

	const std::vector<double> ts(series.cbegin(), series.cend() - 1);

	cv::Mat1d sing_values, V, U;
	//--- SSA
	ssa(ts, sing_values, V, U);
	//--- cmax
	double c0maxval = calc_cmax(ts, sing_values, V, U);

	cv::Mat1d s,u,v;

	if (sing_values.rows > int(m_max_et))
	{

		s = sing_values.rowRange(0, m_max_et);
		u = U.colRange(0, m_max_et);
		v = V.colRange(0, m_max_et);

	}
	else
	{
		s = sing_values;
		u = U;
		v = V;

	}

	// calc trend
	const std::vector<double> res{ calc_trend(ts, c0maxval, s, v, u) };
	m_results = std::move(res);
	return m_results.size();
}

cv::Mat1d CSSA::calc_trend(const std::vector<double> & series, const double c0, const cv::Mat1d &sing_values, const cv::Mat1d &V,const cv::Mat1d &U)
{
	int maxET = U.cols;
	std::vector<double> cval_forET(maxET);

	std::vector<int> trend_ETs;

	for (int et = 0; et < maxET; et++)
	{
		cval_forET[et] = LFvalue_vect(U, m_omega0, et);

		if (cval_forET[et] > c0)trend_ETs.push_back(et);
	}

	return reconstruct(sing_values, U, V, trend_ETs);
}



void CSSA::ssa(const std::vector<double> & series, cv::Mat1d &S, cv::Mat1d &V, cv::Mat1d &U)
{
	int k = m_size - m_L + 1;
	int L = int(m_L);

	std::vector<double> vec;
	vec.reserve(L*k);
	int adj = series.size() - m_size;
	auto it = series.cbegin();

	for (int i = 0; i < L; i++)
	{
		std::copy(it, it + k, std::back_inserter(vec));
		++it;
	}

	cv::Mat1d X(L, k, vec.data());

	// SVD
	cv::SVD::compute(X, S, U, V);
	cv::Mat1d nonZeroSingularValues = S > 0.0001;


	// rank
	int M = cv::countNonZero(nonZeroSingularValues);
	if (M < L)
	{
		S = S.rowRange(0, M);
		U = U.colRange(0, M);
	}
	V = V.rowRange(0, M).t();

}


double CSSA::calc_cmax(const std::vector<double> & series, const cv::Mat1d & sing_values, const cv::Mat1d & V, const cv::Mat1d &U)
{

	cv::Mat1d trend;
	int d = std::min(sing_values.rows, int(m_max_et));
	//  Calculate LowFreq values for all ETs
	std::vector<double>cval_forET(d);
	for (int et = 0; et < d; et++)
	{
		cval_forET[et] = LFvalue_vect(U, m_omega0, et);
	}
	//---
	int c0s_amount = (int)floor((m_c0max - m_c0min) / m_c0step) + 1;

	std::vector<double> crit_LFres;
	std::vector<double> c0s;
	for (int n = 0; n < c0s_amount; n++)
	{
		double c0 = m_c0min + m_c0step*n;
		std::vector<int> trend_ETs;
		for (int et = 0; et < d; et++)
		{
			if (cval_forET[et] > c0) trend_ETs.push_back(et);
		}
		// reconstruct
		const cv::Mat1d trend{reconstruct(sing_values, U, V, trend_ETs)};


		const cv::Mat1d ts{ series };

		double crit = (c0 > 0) ? LF_criteria(ts, trend) : 0;
		c0s.push_back(c0);
		crit_LFres.push_back(crit);

	}
	//---
	int sz = crit_LFres.size();

	const std::valarray<double> tmp(crit_LFres.data(), sz);
	const std::valarray<double> c0dtl = tmp[std::slice(1, sz - 1, 1)] - tmp[std::slice(0, sz - 1, 1)];


	

	double cmax = 1.0;
	for (int i = 0; i < (int)c0dtl.size(); i++)
	{
		if (c0dtl[i] > m_rdelta_threshold)
		{
			cmax = c0s[i];
			break;
		}
	}
	return cmax;
}

size_t CSSA::minmax(const size_t n, const size_t min, const size_t max)
{
	return std::max(min, std::min(max, n));
}

double CSSA::minmax(const double n, const double min, const double max)
{
	return std::max(min, std::min(max, n));
}


double CSSA::LFvalue_vect(const cv::Mat1d & M, const double omega0, const int ET)
{
	int L = M.rows;
	

	double nrm = cv::norm(M.col(ET), cv::NORM_L2);
	if (nrm == 0.0)
	{
		return -1;
	}

	cv::Mat1d vect(M.col(ET).t() / nrm);
	int k = 1;
	double w = 0.0;
	double val = 0;

	while (w < omega0)
	{
		val += periodogram(std::valarray<double>(std::vector<double>(vect).data(), vect.cols), k);
		k = k + 1;
		w = (k - 1.0) / L;
	}

	return val;
}

double CSSA::periodogram(const std::valarray<double>& F, const int k)
{

	int N = F.size();
	double w = (k - 1.0) / N;
	std::valarray<double> T(N);
	for (int i = 0; i < N; ++i) T[i] = (double)i;

	double c = (F * cos(2.0*M_PI*T*w)).sum();
	double s = (F * sin(2.0*M_PI*T*w)).sum();
	double Pi = c*c + s*s;
	Pi = Pi * 2.0 / N;

	if (k == 1 || k == floor(N / 2) + 1) Pi = Pi / 2;
	return Pi;
}

cv::Mat1d CSSA::reconstruct(const cv::Mat1d & sing_values, const cv::Mat1d & U, const cv::Mat1d & V, const std::vector<int> ETs)
{
	int L = U.rows;
	int K = V.rows;
	int N = K + L - 1;
	cv::Mat1d X{ cv::Mat1d::zeros(L, K) };
	for (size_t i = 0; i < ETs.size(); i++)
	{
		int ET = ETs[i];
		const double sing_value{ sing_values(ET,0) };
		const cv::Mat1d u{ U.col(ET) };
		const cv::Mat1d v{ V.col(ET) };
		const cv::Mat1d Xi{ sing_value * u * v.t() };

		X += Xi;
	}
	cv::Mat1d Freq{ cv::Mat1d::zeros(N, 1) };
	int L0 = std::min(L, K);
	int K0 = std::max(L, K);
	cv::Mat1d Y;
	if( L<K )
		Y=X;
	else
		Y=X.t();


	//--- 斜めに加算 前半
	for (int k = 1; k < L0; k++)
	{
		double d = 0.0;
		for (int m = 1; m <= k; m++)
		{
			d += Y( m - 1, k - m);
		}
		Freq(k - 1, 0) = 1.0 / k * d;
	}

	//---
	for (int k = L0; k <= K0; k++)
	{

		double d = 0.0;
		for (int m = 1; m <= L0; m++)
		{
			d += Y(m - 1, k - m);
		}
		Freq(k - 1, 0) = 1.0 / L0 * d;
	}
	//---
	for (int k = K0 + 1; k <= N; k++)
	{
		double d = 0.0;
		for (int m = k - K0 + 1; m <= N - K0 + 1; m++)
		{
			d += Y(m - 1, k - m);
		}

		Freq(k - 1, 0) = 1.0 / (N - k + 1) * d;
	}
	return  Freq;
}

double CSSA::LF_criteria(const cv::Mat1d & ts, const cv::Mat1d & trend)
{

	double lf_ts = LFvalue_vect(ts, m_omega0, 0);
	double lf_res = LFvalue_vect((ts - trend), m_omega0, 0);

	if (lf_ts <= 0 || lf_res <= 0) return 0.0;

	return (lf_res / lf_ts);
}

