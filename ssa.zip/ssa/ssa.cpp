#include "ssa.h"
#include <math.h>
#include <cmath>
#include <iostream>
EXPORT CSSA * __stdcall Create(const unsigned int size, const unsigned int length, const  double omega0, const unsigned int max_et, const double c0step){
	return new CSSA(size, length, omega0, max_et, c0step);
}

EXPORT void __stdcall Destroy(CSSA * instance)
{
	delete instance;
}

EXPORT int __stdcall Push(CSSA * instance, const int x, const double y, const time_t t0, const time_t t1)
{
	return instance->push(x, y, t0, t1);
}
EXPORT int __stdcall Calculate(CSSA* instance)
{
	return instance->calculate();	
}

CSSA::CSSA(const unsigned int size, const unsigned int length, const  double omega0, const unsigned int max_et, const double c0step):
	m_size(minmax(size, 50, 2000)),
	m_L(minmax(length, 5, m_size)),
	m_omega0(minmax(omega0,0.001, 0.5)),
	m_max_et(minmax(max_et, 2, int(0.5*m_L))),
	m_c0min(0.5),
	m_c0max(1.0),
	m_c0step(c0step),
	m_rdelta_threshold(0.05),
	m_c0eps(0),
	m_series(CSeries(m_size+1)),
	m_single_value(0.0),
	m_U(cv::Mat1d(m_L, m_max_et))
{
	std::cout << std::endl;
}


int CSSA::push(const int x, const double y, const time_t t0, const time_t t1)
{
	int result = 0;
	try
	{
		result = m_series.push(x, y, t0, t1);

	}
	catch (...)
	{
		result = -9999;
	}

	return result;
}

int CSSA::calculate()
{
	if (!m_series.is_adding())return false;
	const std::deque<double> & series = m_series.get_stats_series();
	return 0;
}



double calc_cmax() 
{
	return 0.0;
}

unsigned int CSSA::minmax(const unsigned int n, const unsigned int min, const unsigned int max)
{
	return std::max(min, std::min(max, n));
}

double CSSA::minmax(const double n, const double min, const double max)
{
	return std::max(min, std::min(max, n));
}
