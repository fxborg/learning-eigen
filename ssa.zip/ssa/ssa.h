#define EXPORT  extern "C" // __declspec(dllexport)  
#include <deque> 
#include <vector> 
#include <numeric>
#include <cmath>
#include <algorithm>
#include<iterator>
#include "series.h"
#include "opencv2/core/core.hpp"
class CSSA
{
public:
	// �R���X�g���N�^
	explicit CSSA(const unsigned int size, const unsigned int length, const  double omega0, const unsigned int max_et, const double c0step);
	int push(const int x, const double y, const time_t t0, const time_t t1);
	int calculate();



private:
	double calc_cmax();

	unsigned int minmax(const unsigned int n, const unsigned int min, const unsigned int max);
	double minmax(const double n, const double min, const double max);

	const unsigned int m_size;
	const unsigned int m_L;
	const unsigned int m_omega0;
	const unsigned int m_max_et;
	const double m_c0min;
	const double m_c0max;
	const double m_c0step;
	const double m_rdelta_threshold;
	const double m_c0eps;
	CSeries m_series;
	const double m_single_value;
	cv::Mat1d m_U;
	cv::Mat1d m_V;
};

//--- �C���X�^���X�𐶐�
EXPORT CSSA * __stdcall Create(const unsigned int size, const unsigned int length, const  double omega0, const unsigned int max_et, const double c0step);
//--- �C���X�^���X��j��
EXPORT void __stdcall Destroy(CSSA* instance);
//--- �C���X�^���X�o�R��push���\�b�h���R�[��
EXPORT int __stdcall Push(CSSA* instance, const int x, const double y, const time_t t0, const time_t t1);
//--- �\���l���v�Z
EXPORT int __stdcall Calculate(CSSA* instance );

