#define _USE_MATH_DEFINES
#include <deque> 
#include <numeric>
#include <algorithm>
#include <iostream>
#include <math.h>


class CSeries
{
public:
	explicit CSeries(const size_t period); 
	int push(const int x, const double y, const time_t t0, const time_t t1);
	const std::deque<double>& get_stats_series() const;
	size_t minmax(const size_t n, const size_t min, const size_t max);
	void erase(void); 
	int last_x() const;
	int prev_x() const;
	bool is_adding(void) const;
	size_t size(void) const; 
private:
	const size_t m_series_size; 
	time_t m_last_t;
	int m_last_x;
	int m_prev_x;
	std::deque<double> m_buf_stats;
	bool m_is_adding;
};

